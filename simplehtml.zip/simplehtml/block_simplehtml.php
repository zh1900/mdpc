<?php
    class block_simplehtml extends block_base{
        public function init(){
            $this->title = get_string('simplehtml', 'block_simplehtml');

        }

    }