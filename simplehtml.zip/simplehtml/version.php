<?php
$plugin->version =  2018102217;
$plugin->requires = 2014112400;
//$plugin->release = '1.2.1';
$plugin->component = 'block_simplehtml';