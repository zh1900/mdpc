﻿<?PHP
$string['helloworld'] = '你好世界';
?>