# Countdown Moodle plugin / block
Yevhen Matasar (matasar.ei@gmail.com)

Powered by: http://hilios.github.io/jQuery.countdown/
## Installation
* Copy files to <moodle_dir>/blocks/countdown/;
* Add plugin to sidebar;
* Set date and time, title and custom CSS (optional);
* Enjoy.

## Screenshots
### Block
![screenshot 002](https://user-images.githubusercontent.com/6638367/29498017-340472d0-85fc-11e7-900d-f821aba6d4d2.png)
### Settings page
* Title;
* Date and time;
* Text after ended;
* URL;
* Custom css.

![screenshot 001](https://user-images.githubusercontent.com/6638367/29498016-3369b1a0-85fc-11e7-9d2f-b77e39d438fa.png)
